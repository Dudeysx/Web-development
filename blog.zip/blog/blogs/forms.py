from django import forms
from .models import BlogPost
from .models import ModelForm

from .models import Tasks

class AddTaskForm(forms.ModelForm):

    task = forms.CharField(max_length=250,
                           widget = forms.TextInput(
                               attrs = {
                                   'class' : 'form-control',
                                   'placeholder' : 'task?',
                               }
                           )
                           )


class Meta:
    moled = Tasks
    fields = '__all__'


def addTask(request):

    form = AddTaskForm(request.POST)

    if form.is_valid():
        form.save()

    return redirect('/')

def deleteTask(request, id):

    task = Task.objects.get(pk = id)

    task.delete()

    return redirect('/')

def completedTask(request, id):

    task = Task.objects.get(pk = id)

    task.completed = True
    task.save()

    return redirect('/')


def updateTask(request, id):

    task = Task.objects.get(pk = id)
    updateForm = AddTaskForm(instance = task)

    if request.method == 'POST':
        form = AddTaskForm(request.POST, instance = task)
        if form.is_valid():
            form.save()
            return redirect("\")
class BlogPostForm(forms.ModelForm):
    class Meta:
        model = BlogPost
        fields = ['title', 'text']
